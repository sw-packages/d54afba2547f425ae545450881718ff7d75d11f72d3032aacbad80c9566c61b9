//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Weta Digital, Ltd and Contributors to the OpenEXR Project.
//

#ifndef TESTPARTHELPER_H_
#define TESTPARTHELPER_H_

#include <string>
void testPartHelper (const std::string & tempDir);

#endif /* TESTPARTHELPER_H_ */
