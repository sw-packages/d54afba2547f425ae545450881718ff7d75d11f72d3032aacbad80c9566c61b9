//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//

#ifndef TESTCOPYDEEPTILED_H_
#define TESTCOPYDEEPTILED_H_

#include <string>

void testCopyDeepTiled (const std::string & tempDir);

#endif /* TESTCOPYDEEPTILED_H_ */
